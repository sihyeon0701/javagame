package game;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

public class DodgingGame extends JFrame {
    private GamePanel gamePanel;
    private JButton pauseResumeButton;

    public DodgingGame() {
        gamePanel = new GamePanel();
        add(gamePanel);

        // Pause/Resume 버튼
        pauseResumeButton = new JButton("Pause/Resume");
        pauseResumeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gamePanel.togglePause();
                updateButtonLabels();
            }
        });

        // 버튼 패널
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(pauseResumeButton);

        // 프레임에 버튼 패널 추가
        add(buttonPanel, BorderLayout.SOUTH);

        setTitle("Dodging Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 650); // 버튼 패널 추가로 높이 조절
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);

        gamePanel.setFocusable(true);
        gamePanel.requestFocusInWindow();

        gamePanel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                gamePanel.handleKeyPress(evt);
            }
        });
    }

    private void updateButtonLabels() {
        if (gamePanel.isPaused()) {
            pauseResumeButton.setText("Resume");
        } else {
            pauseResumeButton.setText("Pause");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new DodgingGame();
        });
    }
}

class GamePanel extends JPanel {
    private int playerX = 375;
    private int playerY = 500;
    private java.util.List<Dung> dungs = new java.util.concurrent.CopyOnWriteArrayList<>();
    private Timer timer;
    private boolean isGameOver = false;
    private int score = 0;
    private Image backgroundImage;
    private Image playerImage;
    private Image dungImage;

    private boolean isPaused = false;

    public GamePanel() {
        ImageIcon playerIcon = new ImageIcon("사람.png");
        playerImage = playerIcon.getImage();

        ImageIcon dungIcon = new ImageIcon("똥.png");
        dungImage = dungIcon.getImage();

        ImageIcon imageIcon = new ImageIcon("야간배경수정.png");
        backgroundImage = imageIcon.getImage();
        setPreferredSize(new Dimension(800, 600));
        backgroundImage = backgroundImage.getScaledInstance(getPreferredSize().width, getPreferredSize().height, Image.SCALE_SMOOTH);

        timer = new Timer(10, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moveDungs();
                checkCollisions();
                score++;

                if (score == 2000) {
                    isGameOver = true;
                    timer.stop();
                }

                repaint();

                if (isGameOver) {
                    // 게임 오버 시 추가 로직
                }
            }
        });
        timer.start();

        Thread dungThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!isGameOver) {
                    dungs.add(new Dung());
                    try {
                        Thread.sleep(300);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        dungThread.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(backgroundImage, 0, 0, this);

        if (!isGameOver) {
            g.drawImage(playerImage, playerX, playerY, 50, 50, this);

            for (Dung dung : dungs) {
                g.drawImage(dungImage, dung.getX(), dung.getY(), 30, 30, this);
            }

            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.PLAIN, 30));
            g.drawString("Score: " + score, 20, 40);
        } else {
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.PLAIN, 40));
            g.drawString("Game Over!", 320, 300);
            g.setFont(new Font("Arial", Font.PLAIN, 30));
            g.drawString("Score: " + score, 360, 350);
        }
    }

    public void moveDungs() {
        for (Dung dung : dungs) {
            dung.move();
        }
        dungs.removeIf(dung -> dung.getY() > 600);
    }

    public void checkCollisions() {
        Rectangle playerRect = new Rectangle(playerX, playerY, 50, 50);
        for (Dung dung : dungs) {
            Rectangle dungRect = new Rectangle(dung.getX(), dung.getY(), 30, 30);
            if (playerRect.intersects(dungRect)) {
                isGameOver = true;
                timer.stop();
                break;
            }
        }
    }

    public void handleKeyPress(KeyEvent e) {
        if (!isGameOver) {
            int keyCode = e.getKeyCode();
            if (keyCode == KeyEvent.VK_LEFT && playerX > 0) {
                playerX -= 50;
            } else if (keyCode == KeyEvent.VK_RIGHT && playerX < 750) {
                playerX += 50;
            } else if (keyCode == KeyEvent.VK_P) {
                togglePause();
            }
        }
    }

    void togglePause() {
        isPaused = !isPaused;

        if (isPaused) {
            // 타이머 일시 정지
            timer.stop();
        } else {
            // 타이머 재개
            timer.start();
            
            // 기존원인: 키 이벤트 핸들링이 비활성화되어 있는 것이 원인 재시작 시 플레이어가 안움직임 
            // 키 이벤트 핸들링 다시 활성화 해주어야 캐릭터가 다시 움직임 
            setFocusable(true);
            requestFocusInWindow();
        }
    }

    public boolean isPaused() {
        return isPaused;
    }
}

class Dung {
    private int x;
    private int y;

    public Dung() {
        x = (int) (Math.random() * 750);
        y = 0;
    }

    public void move() {
        y += 3;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
