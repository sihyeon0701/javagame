package game;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dinae extends JFrame {

    public Dinae() {
        super("똥피하기 게임"); // 타이틀

        // 배경 이미지가 표시될 패널 생성
        BackgroundPanel jPanel = new BackgroundPanel("야간배경수정.png");

        JButton btn1 = new JButton("게임 시작"); // 이미지 버튼 생성
        btn1.setBounds(300, 450, 200, 50); // 버튼의 위치와 크기를 직접 설정
        jPanel.setLayout(null); // LayoutManager 사용 안 함
        jPanel.add(btn1);
        add(jPanel);

        setSize(800, 600); // 창 크기 설정

        Dimension frameSize = getSize();
        Dimension windowSize = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation((windowSize.width - frameSize.width) / 2,
                (windowSize.height - frameSize.height) / 2); // 화면 중앙에 띄우기
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);

        btn1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new DodgingGame();
                setVisible(false); // 창 안보이게 하기
            }
        });
    }

    private JButton createImageButton(String imagePath) {
        // 이미지 아이콘 생성
        ImageIcon icon = new ImageIcon(imagePath);
        Image image = icon.getImage().getScaledInstance(200, 100, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(image);

        // 이미지 아이콘을 사용한 버튼 생성
        JButton button = new JButton(scaledIcon);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);

        return button;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Dinae();
            }
        });
    }
}

// 배경 이미지를 표시하는 패널
class BackgroundPanel extends JPanel {
    private Image backgroundImage;

    public BackgroundPanel(String imagePath) {
        // 배경 이미지 로드
        ImageIcon imageIcon = new ImageIcon(imagePath);
        backgroundImage = imageIcon.getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // 배경 이미지 그리기
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
    }
}
