package game;

public class ddong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dinae d = new Dinae();
	}

}
