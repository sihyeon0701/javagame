package game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginAndRegisterApp extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginAndRegisterApp() {
        setTitle("Login and Register App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // 배경화면을 그리는 패널 생성
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon imageIcon = new ImageIcon("야간배경수정.png");  
                Image backgroundImage = imageIcon.getImage();
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };

        backgroundPanel.setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(10, 10, 10, 10); // 여백을 크게 조절

        JLabel usernameLabel = new JLabel("ID:");
        JLabel passwordLabel = new JLabel("Password:");

        usernameField = new JTextField();
        passwordField = new JPasswordField();

        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");	

        // 버튼 크기를 크게 조절
        Dimension buttonSize = new Dimension(150, 40);
        loginButton.setPreferredSize(buttonSize);
        registerButton.setPreferredSize(buttonSize);

        // 텍스트 상자와 버튼의 배경색을 노란색으로 설정
        usernameField.setPreferredSize(new Dimension(300, 30));
        usernameField.setBackground(Color.YELLOW);
        passwordField.setPreferredSize(new Dimension(300, 30));
        passwordField.setBackground(Color.YELLOW);
        loginButton.setBackground(Color.YELLOW);
        registerButton.setBackground(Color.YELLOW);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (login(username, password)) {
                    JOptionPane.showMessageDialog(LoginAndRegisterApp.this, "Login successful!");
                    setVisible(false);
                    startDodgingGame();
                } else {
                    JOptionPane.showMessageDialog(LoginAndRegisterApp.this, "Login failed. Please check your credentials.");
                }
            }
        });

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (register(username, password)) {
                    JOptionPane.showMessageDialog(LoginAndRegisterApp.this, "Registration successful!");
                } else {
                    JOptionPane.showMessageDialog(LoginAndRegisterApp.this, "Registration failed. Please try again.");
                }
            }
        });

        // Username label
        constraints.gridx = 0;
        constraints.gridy = 0;
        usernameLabel.setForeground(Color.YELLOW); // 글씨색 노란색으로 설정
        backgroundPanel.add(usernameLabel, constraints);


        // Username field
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.gridwidth = 2;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        backgroundPanel.add(usernameField, constraints);

        // Password label
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.gridwidth = 1;
        passwordLabel.setForeground(Color.YELLOW); // 글씨색 노란색으로 설정
        backgroundPanel.add(passwordLabel, constraints);
        
        // Password field
        constraints.gridx = 1;
        constraints.gridy = 1;
        constraints.gridwidth = 2;
        backgroundPanel.add(passwordField, constraints);

        // Login button
        constraints.gridx = 1;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        backgroundPanel.add(loginButton, constraints);

        // Register button
        constraints.gridx = 2;
        constraints.gridy = 2;
        constraints.gridwidth = 1;
        backgroundPanel.add(registerButton, constraints);

        // 배경 패널을 컨텐트 팬으로 설정
        setContentPane(backgroundPanel);

        setVisible(true);
    }

    private void startDodgingGame() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new DodgingGame();
            }
        });
    }

    private boolean login(String username, String password) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/game", "root", "1234");
            String query = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean register(String username, String password) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/game", "root", "1234");
            String query = "INSERT INTO users (username, password) VALUES (?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            int result = preparedStatement.executeUpdate();
            return result > 0;
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginAndRegisterApp();
            }
        });
    }
}
