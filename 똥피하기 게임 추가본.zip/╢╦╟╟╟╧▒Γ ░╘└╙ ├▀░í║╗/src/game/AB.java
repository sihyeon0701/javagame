package game;

public class AB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoginAndRegisterApp f = new LoginAndRegisterApp();
	}

}
