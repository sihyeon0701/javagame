package game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.awt.Image;
import javax.swing.ImageIcon;

public class DodgingGame extends JFrame {
    private GamePanel gamePanel;

    public DodgingGame() {
        gamePanel = new GamePanel();
        add(gamePanel);

        setTitle("Dodging Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);

        gamePanel.setFocusable(true);
        gamePanel.requestFocusInWindow();

        gamePanel.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                gamePanel.keyPressed(e);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new DodgingGame();
        });
    }
}

class GamePanel extends JPanel {
    private int playerX = 375;
    private int playerY = 500;
    private List<Dung> dungs = new CopyOnWriteArrayList<>();
    private Timer timer;
    private boolean isGameOver = false;
    private int score = 0;
    private Image backgroundImage;
    private Image playerImage;
    private Image dungImage;

    public GamePanel() {
        ImageIcon playerIcon = new ImageIcon("사람.png");
        playerImage = playerIcon.getImage();

        ImageIcon dungIcon = new ImageIcon("똥.png");
        dungImage = dungIcon.getImage();

        ImageIcon imageIcon = new ImageIcon("야간배경수정.png");
        backgroundImage = imageIcon.getImage();
        setPreferredSize(new Dimension(800, 600));
        backgroundImage = backgroundImage.getScaledInstance(getPreferredSize().width, getPreferredSize().height, Image.SCALE_SMOOTH);

        timer = new Timer(10, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moveDungs();
                checkCollisions();
                score++;

                // 스코어 2000점에 도달하면 게임 종료
                if (score == 2000) {
                    isGameOver = true;
                    timer.stop();
                }

                repaint();

                // 게임이 종료되었을 때 
                if (isGameOver) {
                	
                }
            }
        });
        timer.start();

        Thread dungThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!isGameOver) {
                    dungs.add(new Dung());
                    try {
                        Thread.sleep(300);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        dungThread.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(backgroundImage, 0, 0, this);

        if (!isGameOver) {
            g.drawImage(playerImage, playerX, playerY, 50, 50, this);

            for (Dung dung : dungs) {
                g.drawImage(dungImage, dung.getX(), dung.getY(), 30, 30, this);
            }

            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.PLAIN, 30));
            g.drawString("Score: " + score, 20, 40);
        } else {
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.PLAIN, 40));
            g.drawString("Game Over!", 320, 300);
            g.setFont(new Font("Arial", Font.PLAIN, 30));
            g.drawString("Score: " + score, 360, 350);
        }
    }

    public void moveDungs() {
        for (Dung dung : dungs) {
            dung.move();
        }
        dungs.removeIf(dung -> dung.getY() > 600);
    }

    public void checkCollisions() {
        Rectangle playerRect = new Rectangle(playerX, playerY, 50, 50);
        for (Dung dung : dungs) {
            Rectangle dungRect = new Rectangle(dung.getX(), dung.getY(), 30, 30);
            if (playerRect.intersects(dungRect)) {
                isGameOver = true;
                timer.stop();
                break;
            }
        }
    }

    public void keyPressed(KeyEvent e) {
        if (!isGameOver) {
            int keyCode = e.getKeyCode();
            if (keyCode == KeyEvent.VK_LEFT && playerX > 0) {
                playerX -= 50;
            } else if (keyCode == KeyEvent.VK_RIGHT && playerX < 750) {
                playerX += 50;
            }
        }
    }
}

class Dung {
    private int x;
    private int y;

    public Dung() {
        x = (int) (Math.random() * 750);
        y = 0;
    }

    public void move() {
        y += 3;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
